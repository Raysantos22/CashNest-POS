<?php
$host = "localhost";
$username = "scholar3_demo";
$password = "Gagokaba0731?";
$database = "scholar3_second_user_db";

// Establish the connection
$conn = mysqli_connect($host, $username, $password, $database);

// Check the connection
if ($conn) {
    echo "connection successful\n";
} else {
    echo "Connection failed:\n";
    echo "Host: " . $host . "\n";
    echo "Username: " . $username . "\n";
    echo "Database: " . $database . "\n";
    echo "Error: " . mysqli_connect_error() . "\n";
}
?>