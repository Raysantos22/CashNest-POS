const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const net = require('net');
const mysql = require('mysql2/promise');
const app = express();
const axios = require('axios').default;
//const fs = require('fs').promises; //test

// MySQL connection configuration
const dbConfig = {
  host: '127.0.0.1',
  port: 3306,
  user: 'root',
  password: '', // Add your password here if there is one
  database: 'ECPOS', // Assuming ECPOS is the database name
};

// Configure body-parser to handle JSON with increased size limit
app.use(bodyParser.json({limit: '10mb'}));
app.use(bodyParser.urlencoded({extended: true, limit: '10mb'}));

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  
  if (req.method === 'OPTIONS') {
   
    return res.sendStatus(200);
  }
  next();
});

// Request logging middleware
app.use((req, res, next) => {
  console.log('Received request:', {
    method: req.method,
    url: req.url,
    contentType: req.headers['content-type'],
    bodyLength: req.body ? JSON.stringify(req.body).length : 0,
    body: req.body // Log the actual body for debugging
  });
  next();
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error processing request:', err);
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return res.status(400).json({ 
      error: 'Invalid JSON format',
      details: err.message 
    });
  }
  next(err);
});

app.get('/api/getsequence/:storeId', async (req, res) => {
  const { storeId } = req.params;
  console.log(`Received request for number sequence for store: ${storeId}`);

  try {
    // Make a request to the original API 
    
    
    const apiResponse = await axios.get(`https://eljin.org/api/getsequence/${storeId}`);

    // const apiResponse = await axios.get(`http://10.151.5.239:8000/api/getsequence/${storeId}`);
    console.log('API Response:', apiResponse.data);
    

    const numberSequenceValues = apiResponse.data.nubersequencevalues;

    if (!numberSequenceValues || !Array.isArray(numberSequenceValues) || numberSequenceValues.length === 0) {
      console.error('Invalid or empty number sequence received:', numberSequenceValues);
      return res.status(500).json({ error: 'Invalid number sequence data received from API' });
    }

    // Transform the data if needed (though it looks like the structure is already close)
    const transformedSequence = numberSequenceValues.map(sequence => ({
      numberSequence: sequence.NUMBERSEQUENCE,
      nextRec: sequence.NEXTREC,
      cartNextRec: sequence.CARTNEXTREC,
      bundleNextRec: sequence.BUNDLENEXTREC,
      discountNextRec: sequence.DISCOUNTNEXTREC,
      storeId: sequence.STOREID,
      createdAt: sequence.created_at,
      updatedAt: sequence.updated_at,
      wasteRec: sequence.wasterec,
      toNextRec: sequence.TONEXTREC,
      stockNextRec: sequence.STOCKNEXTREC
    }));

    console.log(`Fetched number sequence for store ${storeId}:`, transformedSequence);
res.status(200).json(apiResponse.data);
  } catch (error) {
    console.error('Error fetching number sequence:', error.message);
    res.status(error.response ? error.response.status : 500)
       .json({ error: 'Failed to fetch number sequence', details: error.message });
  }
});
const API_BASE_URL = 'https://eljin.org/api';

app.post('/api/sync-transactions', async (req, res) => {
  try {
    console.log('Processing transaction sync request:', {
      headers: req.headers,
      body: req.body
    });
    
    if (!req.body || !req.body.transactionSummary || !req.body.transactionRecords) {
      return res.status(400).json({
        error: 'Invalid request format',
        details: 'Request must include transactionSummary and transactionRecords'
      });
    }

    const { transactionSummary, transactionRecords } = req.body;

    if (!transactionSummary.store) {
      return res.status(400).json({
        error: 'Missing store information',
        details: 'Store identifier is required in transactionSummary'
      });
    }

    try {
      const storePrefix = transactionSummary.store.toUpperCase();
      // Create store-specific transaction ID
      const uniqueTransactionId = `${storePrefix}${transactionSummary.transactionid}`;
      
      // Create store-specific receipt ID by adding store prefix
      const storeReceiptId = `${storePrefix}${transactionSummary.receiptid}`;

      // First, check for existing transaction in this store
      try {
        const existingTransaction = await axios.get(`${API_BASE_URL}/rbotransactiontables`, {
          params: {
            store: storePrefix,
            transactionid: uniqueTransactionId
          }
        });

        /* if (existingTransaction.data && existingTransaction.data.length > 0) {
          return res.status(400).json({
            message: 'Transaction already exists for this store',
            store: storePrefix,
            transactionId: uniqueTransactionId
          });
        } */


      } catch (error) {
        // If the check fails, log it but continue (might be 404 which is good)
        console.log('Transaction existence check:', error.message);
      }

      // Format transaction summary data
      const summaryData = {
        transactionid: uniqueTransactionId,
        store: storePrefix,
        type: String(transactionSummary.type || '0'),
        receiptid: storeReceiptId, // Use store-specific receipt ID
        staff: transactionSummary.staff,
        custaccount: transactionSummary.custaccount || '',
        cashamount: parseFloat(transactionSummary.cashamount || 0).toFixed(2),
        netamount: parseFloat(transactionSummary.netamount).toFixed(2),
        costamount: parseFloat(transactionSummary.costamount).toFixed(2),
        grossamount: parseFloat(transactionSummary.grossamount).toFixed(2),
        partialpayment: parseFloat(transactionSummary.partialpayment || 0).toFixed(2),
        transactionstatus: parseInt(transactionSummary.transactionstatus || 1),
        discamount: parseFloat(transactionSummary.discamount || 0).toFixed(2),
        custdiscamount: parseFloat(transactionSummary.custdiscamount || 0).toFixed(2),
        totaldiscamount: parseFloat(transactionSummary.totaldiscamount || 0).toFixed(2),
        numberofitems: parseInt(transactionSummary.numberofitems),
        currency: transactionSummary.currency || 'PHP',
        createddate: transactionSummary.createddate,
        window_number: parseInt(transactionSummary.window_number || 0),
        taxinclinprice: parseFloat(transactionSummary.taxinclinprice || 0).toFixed(2),
        netamountnotincltax: parseFloat(transactionSummary.netamountnotincltax || 0).toFixed(2),
        charge: String(parseFloat(transactionSummary.charge || '0.00').toFixed(2)),
        gcash: String(parseFloat(transactionSummary.gcash || '0.00').toFixed(2)),
        paymaya: String(parseFloat(transactionSummary.paymaya || '0.00').toFixed(2)),
        cash: String(parseFloat(transactionSummary.cash || '0.00').toFixed(2)),
        card: String(parseFloat(transactionSummary.card || '0.00').toFixed(2)),
        loyaltycard: String(parseFloat(transactionSummary.loyaltycard || '0.00').toFixed(2)),
        foodpanda: String(parseFloat(transactionSummary.foodpanda || '0.00').toFixed(2)),
        grabfood: String(parseFloat(transactionSummary.grabfood || '0.00').toFixed(2)),
        representation: String(parseFloat(transactionSummary.representation || '0.00').toFixed(2))
      };

      // Post transaction summary
      const summaryResponse = await axios.post(
        `${API_BASE_URL}/rbotransactiontables`,
        summaryData,
        {
          headers: {
            'Content-Type': 'application/json'
          }
        }
      );
const recordPromises = transactionRecords.map(async (record, index) => {
  try {

    const salesTransData = {
      transactionid: uniqueTransactionId,
      linenum: parseInt(record.linenum),
      receiptid: storeReceiptId,
      
      itemid: String(record.itemid || ''),
      itemname: String(record.itemname || record.description || ''),
      itemgroup: String(record.itemgroup || ''),
      
      price: parseFloat(record.price || 0).toFixed(2),
      netprice: parseFloat(record.netprice || record.price || 0).toFixed(2),
      qty: parseInt(record.qty || 1),
      discamount: parseFloat(record.discamount || 0).toFixed(2),
      costamount: parseFloat(record.costamount || 0).toFixed(2),
      netamount: parseFloat(record.netamount || 0).toFixed(2),
      grossamount: parseFloat(record.grossamount || 0).toFixed(2),
      
      custaccount: String(record.custaccount || 'WALK-IN'),
      store: storePrefix,
      priceoverride: parseInt(record.priceoverride || 0),
      paymentmethod: String(record.paymentmethod || 'Cash'),
      staff: String(record.staff || 'Unknown'),
      
      linedscamount: parseFloat(record.linedscamount || 0).toFixed(2),
      linediscpct: parseFloat(record.linediscpct || 0).toFixed(2),
      custdiscamount: parseFloat(record.custdiscamount || 0).toFixed(2),
      
      unit: String(record.unit || 'PCS'),
      unitqty: parseFloat(record.unitqty || record.qty || 1).toFixed(2),
      unitprice: parseFloat(record.unitprice || record.price || 0).toFixed(2),
      taxamount: parseFloat(record.taxamount || 0).toFixed(2),
      
      createddate: record.createddate || new Date().toISOString(),
      remarks: String(record.remarks || ''),
      taxinclinprice: parseFloat(record.taxamount || 0).toFixed(2),
      description: String(record.description || ''),
      
      netamountnotincltax: parseFloat(record.netamountnotincltax || 0).toFixed(2),
      
      inventbatchid: record.inventbatchid || null,
      inventbatchexpdate: record.inventbatchexpdate || null,
      giftcard: record.giftcard || null,
      returntransactionid: record.returntransactionid || null,
      returnqty: record.returnqty ? parseInt(record.returnqty) : null,
      creditmemonumber: record.creditmemonumber || null,
      returnlineid: record.returnlineid || null,
      priceunit: record.priceunit || null,
      storetaxgroup: record.storetaxgroup || null,
      currency: record.currency || 'PHP',
      taxexempt: record.taxexempt || null,
      discountOfferId: String(record.discofferid),
      discofferid: String(record.discofferid)
      };
console.log('Full record details:', {
  discountOfferId: record.discountOfferId,
  discountOfferId11: record.discofferid,
  mixMatchId: record.mixMatchId,
  type: typeof record.discountOfferId
});
    return axios.post(
      `${API_BASE_URL}/rbotransactionsalestrans`,
      salesTransData
    );
  } catch (error) {
    console.error(`Error processing record ${index + 1}:`, {
      error: error.message,
      record: record
    });
    throw error; 
  }
});

      const recordsResponse = await Promise.all(recordPromises);

      return res.status(200).json({
        message: 'Transaction synced successfully',
        store: storePrefix,
        transactionId: uniqueTransactionId,
        receiptId: storeReceiptId,
        summaryResponse: summaryResponse.data,
        recordsResponse: recordsResponse.map(r => r.data)
      });

    } catch (error) {
      console.error('Error sending to API:', {
        message: error.message,
        response: error.response && error.response.data,
        status: error.response && error.response.status
      });
      
      let errorStatus = 500;
      let errorMessage = error.message;
      let errorDetails = error.message;

      if (error.response) {
        errorStatus = error.response.status || 500;
        if (error.response.data && error.response.data.message) {
          errorDetails = error.response.data.message;
        }
      }
      
      return res.status(errorStatus).json({
        error: 'Failed to sync with API',
        details: errorDetails,
        status: errorStatus
      });
    }

  } catch (error) {
    console.error('Error processing transaction:', error);
    return res.status(500).json({
      error: 'Failed to process transaction',
      details: error.message,
      stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
    });
  }
});















// Add this to your existing express app configuration
app.post('/api/transaction-refund/:storeid/:count', async (req, res) => {
  try {
    console.log('Processing refund request:', {
      headers: req.headers,
      body: req.body,
      params: req.params
    });

    const { storeid, count } = req.params;
    const refundData = req.body;

    // Validate request
    if (!refundData || !refundData.transactionid || !refundData.items || !Array.isArray(refundData.items)) {
      return res.status(400).json({
        error: 'Invalid request format',
        details: 'Request must include transactionid and items array'
      });
    }

    // Generate refund receipt ID
    const storePrefix = storeid.toUpperCase();
    const refundReceiptId = `RF${count}-${storePrefix}-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}`;

    // Calculate totals
    let totalRefundAmount = 0;
    let totalRefundCost = 0;
    let totalRefundTax = 0;
    let totalRefundDisc = 0;

    refundData.items.forEach(item => {
      totalRefundAmount += parseFloat(item.netamount || 0);
      totalRefundCost += parseFloat(item.costamount || 0);
      totalRefundTax += parseFloat(item.taxamount || 0);
      totalRefundDisc += parseFloat(item.discamount || 0);
    });

    // Format transaction table update data
    const transactionUpdate = {
      refundreceiptid: refundReceiptId,
      refunddate: new Date().toISOString(),
      refundby: refundData.refundby,
      netamount: formatDecimal(-totalRefundAmount),
      costamount: formatDecimal(-totalRefundCost),
      grossamount: formatDecimal(-totalRefundAmount),
      discamount: formatDecimal(-totalRefundDisc),
      transactionstatus: refundData.transactionstatus || 2, // Default to refunded status
      type: refundData.type || 'REFUND',
      custaccount: refundData.custaccount,
      cashamount: formatDecimal(refundData.cashamount),
      partialpayment: formatDecimal(refundData.partialpayment),
      custdiscamount: formatDecimal(refundData.custdiscamount),
      totaldiscamount: formatDecimal(refundData.totaldiscamount),
      numberofitems: refundData.numberofitems,
      currency: refundData.currency || 'PHP',
      zreportid: refundData.zreportid,
      comment: refundData.comment,
      receiptemail: refundData.receiptemail,
      markupamount: formatDecimal(refundData.markupamount),
      markupdescription: refundData.markupdescription,
      taxinclinprice: formatDecimal(refundData.taxinclinprice),
      netamountnotincltax: formatDecimal(refundData.netamountnotincltax),
      window_number: refundData.window_number || 0,
      charge: formatDecimal(refundData.charge),
      gcash: formatDecimal(refundData.gcash),
      paymaya: formatDecimal(refundData.paymaya),
      cash: formatDecimal(refundData.cash),
      card: formatDecimal(refundData.card),
      loyaltycard: formatDecimal(refundData.loyaltycard),
      foodpanda: formatDecimal(refundData.foodpanda),
      grabfood: formatDecimal(refundData.grabfood),
      representation: formatDecimal(refundData.representation)
    };

    // Update transaction table
    const transactionResponse = await axios.put(
      `${API_BASE_URL}/rbotransactiontables/${refundData.transactionid}`,
      transactionUpdate,
      {
        headers: { 'Content-Type': 'application/json' }
      }
    );

    // Process each refund item
    const itemPromises = refundData.items.map(async (item, index) => {
      const salesTransData = {
        transactionid: refundData.transactionid,
        linenum: item.linenum,
        receiptid: refundReceiptId,
        itemid: item.itemid,
        itemname: item.itemname || item.description || '',
        itemgroup: item.itemgroup || '',
        price: formatDecimal(item.price),
        netprice: formatDecimal(item.netprice),
        qty: parseInt(item.qty || 0),
        returnqty: parseInt(item.returnqty || 0),
        discamount: formatDecimal(item.discamount),
        costamount: formatDecimal(item.costamount),
        netamount: formatDecimal(-item.netamount),
        grossamount: formatDecimal(-item.grossamount),
        custaccount: item.custaccount || 'WALK-IN',
        store: storePrefix,
        priceoverride: parseInt(item.priceoverride || 0),
        paymentmethod: item.paymentmethod || 'REFUND',
        staff: refundData.refundby,
        linedscamount: formatDecimal(item.linedscamount),
        linediscpct: formatDecimal(item.linediscpct),
        custdiscamount: formatDecimal(item.custdiscamount),
        unit: item.unit || 'PCS',
        unitqty: formatDecimal(item.unitqty),
        unitprice: formatDecimal(item.unitprice),
        taxamount: formatDecimal(item.taxamount),
        createddate: new Date().toISOString(),
        remarks: item.remarks || 'Refund',
        inventbatchid: item.inventbatchid,
        inventbatchexpdate: item.inventbatchexpdate,
        giftcard: item.giftcard,
        returntransactionid: refundData.transactionid,
        refunddate: new Date().toISOString(),
        refundby: refundData.refundby,
        creditmemonumber: refundReceiptId,
        description: item.description || '',
        returnlineid: item.linenum,
        priceunit: formatDecimal(item.priceunit),
        netamountnotincltax: formatDecimal(item.netamountnotincltax),
        storetaxgroup: item.storetaxgroup,
        currency: item.currency || 'PHP',
        taxexempt: formatDecimal(item.taxexempt),
        wintransid: item.wintransid
      };

      return axios.put(
        `${API_BASE_URL}/rbotransactionsalestrans/${refundData.transactionid}/${item.linenum}`,
        salesTransData,
        {
          headers: { 'Content-Type': 'application/json' }
        }
      );
    });

    // Wait for all updates to complete
    const itemsResponse = await Promise.all(itemPromises);

    return res.status(200).json({
      message: 'Refund processed successfully',
      store: storePrefix,
      refundReceiptId: refundReceiptId,
      transactionId: refundData.transactionid,
      summary: {
        totalRefundAmount: formatDecimal(totalRefundAmount),
        totalRefundCost: formatDecimal(totalRefundCost),
        totalRefundTax: formatDecimal(totalRefundTax),
        totalRefundDisc: formatDecimal(totalRefundDisc)
      },
      transactionResponse: transactionResponse.data,
      itemsResponse: itemsResponse.map(r => r.data)
    });

  } catch (error) {
    console.error('Error processing refund:', {
      message: error.message,
      response: error.response && error.response.data,
      status: error.response && error.response.status
    });

    let errorStatus = 500;
    let errorMessage = 'Failed to process refund';
    let errorDetails = error.message;

    if (error.response) {
      errorStatus = error.response.status || 500;
      if (error.response.data && error.response.data.message) {
        errorDetails = error.response.data.message;
      }
    }

    return res.status(errorStatus).json({
      error: errorMessage,
      details: errorDetails,
      status: errorStatus
    });
  }
});

// const API_BASE_URL = 'http://10.151.5.239:8000/api';

// app.post('/api/sync-transactions', async (req, res) => {
//   try {
//     console.log('Processing transaction sync request:', {
//       headers: req.headers,
//       body: req.body
//     });
    
//     if (!req.body || !req.body.transactionSummary || !req.body.transactionRecords) {
//       return res.status(400).json({
//         error: 'Invalid request format',
//         details: 'Request must include transactionSummary and transactionRecords'
//       });
//     }

//     const { transactionSummary, transactionRecords } = req.body;

//     if (!transactionSummary.store) {
//       return res.status(400).json({
//         error: 'Missing store information',
//         details: 'Store identifier is required in transactionSummary'
//       });
//     }

//     try {
//       const storePrefix = transactionSummary.store.toUpperCase();
//       const uniqueTransactionId = `${storePrefix}${transactionSummary.transactionid}`;
//       const storeReceiptId = `${storePrefix}${transactionSummary.receiptid}`;

//       // First, delete existing transaction details if any exist
//       try {
//         await axios.delete(`${API_BASE_URL}/rbotransactionsalestrans`, {
//           params: {
//             store: storePrefix,
//             transactionid: uniqueTransactionId
//           }
//         });
//       } catch (error) {
//         console.log('Delete existing records (if any):', error.message);
//         // Continue even if delete fails
//       }

//       // Process transaction records first
//       let failedRecords = [];
//       let successfulRecords = [];
      
//       // Process all transaction details first
//       for (let i = 0; i < transactionRecords.length; i++) {
//         const record = transactionRecords[i];
//         try {
//           const salesTransData = {
//             transactionid: uniqueTransactionId,
//             linenum: record.linenum || (i + 1),
//             receiptid: storeReceiptId,
//             itemid: record.itemid,
//             itemname: record.itemname || record.description || '',
//             itemgroup: record.itemgroup || '',
//             price: parseFloat(record.price).toFixed(2),
//             netprice: parseFloat(record.netprice).toFixed(2),
//             qty: parseInt(record.qty),
//             discamount: parseFloat(record.discamount || 0).toFixed(2),
//             costamount: parseFloat(record.costamount).toFixed(2),
//             netamount: parseFloat(record.netamount).toFixed(2),
//             grossamount: parseFloat(record.grossamount).toFixed(2),
//             custaccount: record.custaccount || 'WALK-IN',
//             store: storePrefix,
//             priceoverride: parseInt(record.priceoverride || 0),
//             paymentmethod: record.paymentmethod || 'Cash',
//             staff: record.staff,
//             linedscamount: parseFloat(record.linedscamount || 0).toFixed(2),
//             linediscpct: parseFloat(record.linediscpct || 0).toFixed(2),
//             custdiscamount: parseFloat(record.custdiscamount || 0).toFixed(2),
//             unit: record.unit || 'PCS',
//             unitqty: parseFloat(record.unitqty).toFixed(2),
//             unitprice: parseFloat(record.unitprice).toFixed(2),
//             taxamount: parseFloat(record.taxamount || 0).toFixed(2),
//             createddate: record.createddate,
//             remarks: record.remarks || '',
//             taxinclinprice: parseInt(record.taxinclinprice || 0),
//             description: record.description || '',
//             netamountnotincltax: parseFloat(record.netamountnotincltax || 0).toFixed(2),
//           };

//           const response = await axios.post(
//             `${API_BASE_URL}/rbotransactionsalestrans`,
//             salesTransData
//           );
//           successfulRecords.push({
//             linenum: record.linenum || (i + 1),
//             response: response.data
//           });
//         } catch (error) {
//           failedRecords.push({
//             linenum: record.linenum || (i + 1),
//             error: error.message,
//             details: error.response && error.response.data ? error.response.data : error.message
//           });
//         }
//       }

//       // Try to update summary data regardless of whether it exists
//       const summaryData = {
//         transactionid: uniqueTransactionId,
//         store: storePrefix,
//         type: String(transactionSummary.type || '0'),
//         receiptid: storeReceiptId,
//         staff: transactionSummary.staff,
//         custaccount: transactionSummary.custaccount || '',
//         cashamount: parseFloat(transactionSummary.cashamount || 0).toFixed(2),
//         netamount: parseFloat(transactionSummary.netamount).toFixed(2),
//         costamount: parseFloat(transactionSummary.costamount).toFixed(2),
//         grossamount: parseFloat(transactionSummary.grossamount).toFixed(2),
//         partialpayment: parseFloat(transactionSummary.partialpayment || 0).toFixed(2),
//         transactionstatus: parseInt(transactionSummary.transactionstatus || 1),
//         discamount: parseFloat(transactionSummary.discamount || 0).toFixed(2),
//         custdiscamount: parseFloat(transactionSummary.custdiscamount || 0).toFixed(2),
//         totaldiscamount: parseFloat(transactionSummary.totaldiscamount || 0).toFixed(2),
//         numberofitems: parseInt(transactionSummary.numberofitems),
//         currency: transactionSummary.currency || 'PHP',
//         createddate: transactionSummary.createddate,
//         window_number: parseInt(transactionSummary.window_number || 0),
//         taxinclinprice: parseFloat(transactionSummary.taxinclinprice || 0).toFixed(2),
//         netamountnotincltax: parseFloat(transactionSummary.netamountnotincltax || 0).toFixed(2),
//         charge: String(parseFloat(transactionSummary.charge || '0.00').toFixed(2)),
//         gcash: String(parseFloat(transactionSummary.gcash || '0.00').toFixed(2)),
//         paymaya: String(parseFloat(transactionSummary.paymaya || '0.00').toFixed(2)),
//         cash: String(parseFloat(transactionSummary.cash || '0.00').toFixed(2)),
//         card: String(parseFloat(transactionSummary.card || '0.00').toFixed(2)),
//         loyaltycard: String(parseFloat(transactionSummary.loyaltycard || '0.00').toFixed(2)),
//         foodpanda: String(parseFloat(transactionSummary.foodpanda || '0.00').toFixed(2)),
//         grabfood: String(parseFloat(transactionSummary.grabfood || '0.00').toFixed(2)),
//         representation: String(parseFloat(transactionSummary.representation || '0.00').toFixed(2))
//       };

//       let summaryResponse;
//       try {
//         // Try to update existing summary first
//         summaryResponse = await axios.put(
//           `${API_BASE_URL}/rbotransactiontables/${uniqueTransactionId}`,
//           summaryData
//         );
//       } catch (error) {
//         // If update fails, try to create new summary
//         try {
//           summaryResponse = await axios.post(
//             `${API_BASE_URL}/rbotransactiontables`,
//             summaryData
//           );
//         } catch (summaryError) {
//           console.log('Warning: Could not update or create summary:', summaryError.message);
//           // Continue even if summary fails - we still want to return the details status
//         }
//       }

//       const response = {
//         message: 'Transaction details processed',
//         store: storePrefix,
//         transactionId: uniqueTransactionId,
//         receiptId: storeReceiptId,
//         totalRecords: transactionRecords.length,
//         successfulRecords: successfulRecords.length,
//         summaryStatus: summaryResponse ? 'success' : 'warning'
//       };

//       if (failedRecords.length > 0) {
//         response.warning = 'Some records failed to process';
//         response.failedRecords = failedRecords;
//         return res.status(207).json(response);
//       }

//       return res.status(200).json(response);

//     } catch (error) {
//       console.error('Error sending to API:', {
//         message: error.message,
//         response: error.response && error.response.data,
//         status: error.response && error.response.status
//       });
      
//       return res.status(500).json({
//         error: 'Failed to sync with API',
//         details: error.response && error.response.data ? error.response.data : error.message
//       });
//     }

//   } catch (error) {
//     console.error('Error processing transaction:', error);
//     return res.status(500).json({
//       error: 'Failed to process transaction',
//       details: error.message,
//       stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
//     });
//   }
// });
// Modified server-side API endpoint handler
// API endpoint code (Node.js)



app.get('/api/users', async (req, res) => {
  console.log('Received get all users request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/getallusers', { timeout: 30000 });
    console.log('API Response:', apiResponse.data);

    const users = apiResponse.data;

    if (!users || users.length === 0) {
      console.error('No users received from API');
      return res.status(404).json({ error: 'No users found' });
    }

    const transformedUsers = users.map(user => ({
      id: user.id || 'Unknown',
      name: user.name || 'Unknown User',
      email: user.email || '',
      storeid: user.storeid  ||'',
      password: user.password || '',
      two_factor_secret: user.two_factor_secret || null,
      two_factor_recovery_codes: user.two_factor_recovery_codes || null,
      remember_token: user.remember_token || null,
      current_team_id: user.current_team_id || null,
      profile_photo_path: user.profile_photo_path || null,
      role: user.role || 'user'
    }));

    console.log(`Transformed ${transformedUsers.length} users`);
    res.status(200).json(transformedUsers);
  } catch (error) {
    console.error('Error fetching users:', error.message);
    if (error.response) {
      console.error('API responded with:', error.response.status, error.response.data);
      res.status(error.response.status).json({ error: 'Error from external API', details: error.response.data });
    } else if (error.request) {
      console.error('No response received from API');
      res.status(503).json({ error: 'External API is unavailable' });
    } else {
      console.error('Error setting up the request:', error.message);
      res.status(500).json({ error: 'Internal server error', details: error.message });
    }
  }
});


app.get('/api/products/get-all-products', async (req, res) => {
  console.log('Received get all products request');
  try {
    const apiResponse = await axios.get(`https://eljin.org/api/items`);
    const items = apiResponse.data.items;
    


    if (!items || items.length === 0) {
      throw new Error('No items received from API');
    }

    const transformedProducts = items.map(product => ({
      itemid: product.itemid || 'Unknown',
      activeOnDelivery: product.Activeondelivery === 1,
      itemName: product.itemname || 'Unknown Item',
      itemGroup: product.itemgroup || '',
      specialGroup: product.specialgroup || '',
      production: product.production || '',
      moq: product.moq || 0,
      price: product.price || 0,
      cost: product.cost || 0,
      barcode: product.barcode === 'N/A' ? 0 : parseInt(product.barcode, 10) || 0
    }));

    console.log(`Transformed ${transformedProducts.length} products`);
    res.status(200).json(transformedProducts);
  } catch (error) {
    console.erro
    r('Error fetching products:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

app.get('/api/customers', async (req, res) => {
  console.log('Received get all customers request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/customers');
    console.log('API Response:', apiResponse.data);

    const customers = apiResponse.data.customers;

    if (!customers || !Array.isArray(customers) || customers.length === 0) {
      console.error('Invalid or empty customers received:', customers);
      return res.status(500).json({ error: 'Invalid customer data received from API' });
    }

    const transformedCustomers = customers.map(customer => ({
      id: customer.id,
      accountNum: customer.accountnum,
      name: customer.name,
      address: customer.address,
      phone: customer.phone,
      email: customer.email
    }));

    console.log(`Transformed ${transformedCustomers.length} customers:`, transformedCustomers);
    res.status(200).json(transformedCustomers);
  } catch (error) {
    console.error('Error fetching customers:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

// AR Types API endpoint
app.get('/api/ar-types', async (req, res) => {
  console.log('Received get all AR types request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/ar');
    console.log('API Response:', apiResponse.data);

    let arTypes = apiResponse.data.arTypes || apiResponse.data.ar || [];

    if (!Array.isArray(arTypes)) {
      console.warn('AR types is not an array. Converting to array.');
      arTypes = [arTypes];
    }

    if (arTypes.length === 0) {
      console.warn('No AR types found');
      return res.status(200).json([]);
    }

    const transformedARTypes = arTypes.map(arType => ({
      id: arType.id,
      ar: arType.ar
    }));

    console.log(`Transformed ${transformedARTypes.length} AR types:`, transformedARTypes);
    res.status(200).json(transformedARTypes);
  } catch (error) {
    console.error('Error fetching AR types:', error.message);
    if (error.response && error.response.status === 404) {
      console.warn('Internal API returned 404. Sending empty array.');
      return res.status(200).json([]);
    }
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

app.get('/api/categories/get-all-categories', async (req, res) => {
  console.log('Received get all categories request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/bwcategory');
    console.log('API Response:', apiResponse.data);

    const categories = apiResponse.data.rboinventitemretailgroups;

    if (!categories || !Array.isArray(categories) || categories.length === 0) {
      console.error('Invalid or empty categories received:', categories);
      return res.status(500).json({ error: 'Invalid categories data received from API' });
    }

    const transformedCategories = categories.map(category => ({
      groupId: parseInt(category.GROUPID, 10),
      name: category.NAME || 'Unknown Category'
    }));

    console.log(`Transformed ${transformedCategories.length} categories:`, transformedCategories);
    res.status(200).json(transformedCategories);
  } catch (error) {
    console.error('Error fetching categories:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

app.get('/api/windowtable/get-all-tables', async (req, res) => {
  console.log('Received get all window tables request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/windowtables');
    console.log('API Response:', apiResponse.data);

    const windowTables = apiResponse.data.windowtables; // Changed from windowTables to windowtables

    if (!windowTables || !Array.isArray(windowTables) || windowTables.length === 0) {
      console.error('Invalid or empty window tables received:', windowTables);
      return res.status(500).json({ error: 'Invalid window table data received from API' });
    }

    const transformedWindowTables = windowTables.map(table => ({
      id: parseInt(table.ID, 10),
      description: table.DESCRIPTION || 'Unknown Table'  // Changed from NAME to DESCRIPTION
    }));

    console.log(`Transformed ${transformedWindowTables.length} window tables:`, transformedWindowTables);
    res.status(200).json(transformedWindowTables);
  } catch (error) {
    console.error('Error fetching window tables:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});
app.get('/api/windows/get-all-windows', async (req, res) => {
  console.log('Received get all windows request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/windowtrans');
    console.log('API Response:', apiResponse.data);

    const windows = apiResponse.data.windowtrans; // Correctly access the 'windowtrans' property

    if (!windows || !Array.isArray(windows) || windows.length === 0) {
      console.error('Invalid or empty windows received:', windows);
      return res.status(500).json({ error: 'Invalid window data received from API' });
    }

    // Add 'windownum' along with 'ID' and 'DESCRIPTION' in the transformed data
    const transformedWindows = windows.map(window => ({
      id: parseInt(window.ID, 10),
      description: window.DESCRIPTION || 'Unknown Window',
      windownum: window.WINDOWNUM // Add the new value
    }));

    console.log(`Transformed ${transformedWindows.length} windows:`, transformedWindows);
    res.status(200).json(transformedWindows);
  } catch (error) {
    console.error('Error fetching windows:', error.message);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});




app.get('/api/discounts/get-all-discounts', async (req, res) => {
  console.log('Received get all discounts request');
  try {
    const apiResponse = await axios.get('https://eljin.org/api/discounts');
    console.log('API Response:', apiResponse.data);
    // const apiResponse = await axios.get('https://fakestoreapi.com/products');
    // const items = apiResponse.data;
    let discounts = apiResponse.data.discounts || apiResponse.data;

    if (!Array.isArray(discounts) || discounts.length === 0) {
      console.warn('Invalid or empty discount data received:', discounts);
      return res.status(200).json([]); // Return an empty array instead of an error
    }

    const transformedDiscounts = discounts.map(discount => ({
      id: parseInt(discount.ID || discount.id, 10) || 0,
      DISCOFFERNAME: (discount.DISCOFFERNAME || discount.discountOfferName || '').trim() || 'Unknown Discount',
      PARAMETER: parseInt(discount.PARAMETER || discount.parameter, 10) || 0,
      DISCOUNTTYPE: ((discount.DISCOUNTTYPE || discount.discountType || '').toLowerCase() || 'unknown').trim()
    }));

    console.log(`Transformed ${transformedDiscounts.length} discounts:`, transformedDiscounts);
    res.status(200).json(transformedDiscounts);
  } catch (error) {
    console.error('Error fetching discounts:', error.message);
    console.error('Error details:', error.response ? error.response.data : 'No response data');
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

// Mix Match API endpoint
app.get('/mixmatch', async (req, res) => {
  console.log('Received get all mix match request');
  try {
      const apiResponse = await axios.get('https://eljin.org/api/mix-match/discounts');
      console.log('API Response:', apiResponse.data);
      
      let mixMatches = apiResponse.data.mixMatches || apiResponse.data || [];

      if (!Array.isArray(mixMatches)) {
          console.warn('Invalid mix match data received, converting to array:', mixMatches);
          mixMatches = [mixMatches].filter(Boolean);
      }

      const transformedMixMatches = mixMatches.map(mixMatch => {
          // Ensure required fields have default values
          const defaultMixMatch = {
              id: '',
              name: 'Unnamed Mix Match', // Add default name
              description: '',
              discounttype: 0,
              dealpricevalue: 0.0,
              discountpctvalue: 0.0,
              discountamountvalue: 0.0,
              line_groups: []
          };

          // Merge with actual data
          const data = Object.assign({}, defaultMixMatch, mixMatch);

          return {
              id: data.id.toString(),
              name: data.name || `Mix Match ${data.id}`, // Ensure name is never null
              description: data.description || 'No Description',
              discounttype: parseInt(data.discounttype, 10) || 0,
              dealpricevalue: parseFloat(data.dealpricevalue) || 0.0,
              discountpctvalue: parseFloat(data.discountpctvalue) || 0.0,
              discountamountvalue: parseFloat(data.discountamountvalue) || 0.0,
              line_groups: (data.line_groups || []).map(group => {
                  const defaultGroup = {
                      linegroup: '',
                      name: 'Unnamed Group', // Add default name for group
                      description: '',
                      noofitemsneeded: 0,
                      discount_lines: []
                  };
                  const groupData = Object.assign({}, defaultGroup, group);

                  return {
                      linegroup: groupData.linegroup || 'DEFAULT_GROUP',
                      name: groupData.name || `Group ${groupData.linegroup}`, // Ensure group name is never null
                      description: groupData.description || 'No Description',
                      noofitemsneeded: parseInt(groupData.noofitemsneeded, 10) || 1,
                      discount_lines: (groupData.discount_lines || []).map(line => {
                          const defaultLine = {
                              id: 0,
                              itemid: '',
                              name: 'Unnamed Item', // Add default name for line
                              disctype: 0,
                              dealpriceordiscpct: 0.0,
                              linegroup: '',
                              qty: 0,
                              itemData: {
                                  itemid: '',
                                  name: 'Default Item', // Add default name for itemData
                                  Activeondelivery: 0,
                                  itemname: 'Default Item',
                                  itemgroup: 'Default Group',
                                  specialgroup: 'Regular',
                                  production: 'Default',
                                  moq: 1,
                                  price: 0.0,
                                  cost: 0.0,
                                  barcode: 'N/A'
                              }
                          };
                          const lineData = Object.assign({}, defaultLine, line);
                          const itemData = Object.assign({}, defaultLine.itemData, line.itemData || {});

                          return {
                              id: parseInt(lineData.id, 10) || 0,
                              itemid: lineData.itemid || 'DEFAULT_ITEM',
                              name: lineData.name || `Item ${lineData.itemid}`, // Ensure line name is never null
                              disctype: parseInt(lineData.disctype, 10) || 0,
                              dealpriceordiscpct: parseFloat(lineData.dealpriceordiscpct) || 0.0,
                              linegroup: lineData.linegroup || groupData.linegroup,
                              qty: parseInt(lineData.qty, 10) || 1,
                              itemData: {
                                  itemid: itemData.itemid || 'DEFAULT_ITEM',
                                  name: itemData.name || itemData.itemname || 'Default Item', // Ensure itemData name is never null
                                  Activeondelivery: parseInt(itemData.Activeondelivery, 10) || 0,
                                  itemname: itemData.itemname || 'Default Item',
                                  itemgroup: itemData.itemgroup || 'Default Group',
                                  specialgroup: itemData.specialgroup || 'Regular',
                                  production: itemData.production || 'Default',
                                  moq: parseInt(itemData.moq, 10) || 1,
                                  price: parseFloat(itemData.price) || 0.0,
                                  cost: parseFloat(itemData.cost) || 0.0,
                                  barcode: itemData.barcode || 'N/A'
                              }
                          };
                      })
                  };
              })
          };
      });

      console.log(`Transformed ${transformedMixMatches.length} mix matches:`, transformedMixMatches);
      res.status(200).json(transformedMixMatches);

  } catch (error) {
      console.error('Error fetching mix matches:', error.message);
      console.error('Error details:', error.response ? error.response.data : 'No response data');
      res.status(500).json({ 
          error: 'Internal server error', 
          details: error.message,
          data: [] // Return empty array on error
      });
  }
});



// app.get('/api/products/get-all-products', async (req, res) => {
//   console.log('Received get all products request');
//   try {
//     const apiResponse = await axios.get('https://fakestoreapi.com/products');
//     const items = apiResponse.data;

//     if (!items || items.length === 0) {
//       throw new Error('No items received from API');
//     }

//     const transformedProducts = items.map(product => ({
//             itemid: product.itemid || 'Unknown',
//             activeOnDelivery: product.Activeondelivery === 1,
//             itemName: product.itemname || 'Unknown Item',
//             itemGroup: product.itemgroup || '',
//             specialGroup: product.specialgroup || '',
//             production: product.production || '',
//             moq: product.moq || 0,
//             price: product.price || 0,
//             cost: product.cost || 0,
//             barcode: product.barcode === 'N/A' ? 0 : parseInt(product.barcode, 10) || 0
//           }));

//     console.log(`Transformed ${transformedProducts.length} products`);
//     res.status(200).json(transformedProducts);
//   } catch (error) {
//     console.error('Error fetching products:', error);
//     res.status(500).json({ error: 'Internal server error' });
//   }
// });


// Start the server



// Create MySQL connection pool
const pool = mysql.createPool(dbConfig);

// Function to find an available port
function findAvailablePort(startPort) {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.listen(startPort, () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        findAvailablePort(startPort + 1).then(resolve, reject);
      } else {
        reject(err);
      }
    });
  });
}



// Add this to your existing server code
// Transaction API endpoints


// Helper function to safely access nested properties

// Helper function for decimal formatting
function formatDecimal(value) {
  if (value === undefined || value === null || value === '') {
    return '0.00';
  }
  return Number(value).toFixed(2);
}
// Increase the limit of the JSON body parser
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

// Root route
app.get('/', (req, res) => {
  res.json({ message: 'Welcome to the ECPOS backend server with MySQL integration!' });
});

// Get all products from MySQL

// Start the server
async function startServer() {
  try {

    const port = await findAvailablePort(3000);
    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1);
  }
}

startServer();